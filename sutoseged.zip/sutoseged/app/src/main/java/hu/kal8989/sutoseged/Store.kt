package hu.kal8989.sutoseged

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Store(context: Context) {

    private val prefs = context.getSharedPreferences("sutoseged", Context.MODE_PRIVATE)
    private val plansFile = File(context.filesDir, "plans.json")
    val photoDir: File = File(context.filesDir, "photos").apply { mkdirs() }

    var apiKey: String
        get() = prefs.getString("apiKey", "") ?: ""
        set(v) = prefs.edit().putString("apiKey", v).apply()

    var model: String
        get() = prefs.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) = prefs.edit().putString("model", v).apply()

    fun loadPlans(): List<SavedPlan> {
        if (!plansFile.exists()) return emptyList()
        return try {
            val arr = JSONArray(plansFile.readText())
            val out = mutableListOf<SavedPlan>()
            for (i in 0 until arr.length()) {
                arr.optJSONObject(i)?.let { out.add(SavedPlan.from(it)) }
            }
            out.sortedByDescending { it.createdAt }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun savePlans(plans: List<SavedPlan>) {
        val arr = JSONArray()
        plans.forEach { arr.put(it.toJson()) }
        plansFile.writeText(arr.toString())
    }

    fun addPlan(inputSummary: String, plan: Plan): SavedPlan {
        val saved = SavedPlan(
            id = System.currentTimeMillis(),
            createdAt = System.currentTimeMillis(),
            inputSummary = inputSummary,
            plan = plan,
            notes = emptyList(),
            photoPath = null
        )
        savePlans(listOf(saved) + loadPlans())
        return saved
    }

    fun updatePlan(updated: SavedPlan) {
        savePlans(loadPlans().map { if (it.id == updated.id) updated else it })
    }

    fun deletePlan(id: Long) {
        val plans = loadPlans()
        plans.firstOrNull { it.id == id }?.photoPath?.let { runCatching { File(it).delete() } }
        savePlans(plans.filter { it.id != id })
    }

    fun newPhotoFile(): File = File(photoDir, "photo_${System.currentTimeMillis()}.jpg")

    companion object {
        const val DEFAULT_MODEL = "gemini-2.5-flash"
        val KNOWN_MODELS = listOf(
            "gemini-2.5-flash",
            "gemini-2.5-pro",
            "gemini-2.0-flash"
        )
    }
}

fun JSONObject.optStringOrNull(key: String): String? =
    optString(key).takeIf { it.isNotBlank() }
