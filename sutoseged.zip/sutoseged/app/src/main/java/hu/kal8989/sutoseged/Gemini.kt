package hu.kal8989.sutoseged

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL

object Gemini {

    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models"

    /**
     * Elküldi a kérést a Gemini API-nak és visszaadja a kész tervet.
     * @param history korábbi körök (szerep to szöveg) — a recept-finomításhoz kell majd
     */
    suspend fun plan(
        apiKey: String,
        model: String,
        userPrompt: String,
        history: List<Pair<String, String>> = emptyList()
    ): Result<Plan> = withContext(Dispatchers.IO) {
        try {
            val raw = call(apiKey, model, userPrompt, history).getOrThrow()
            val cleaned = stripFences(raw)
            Result.success(Plan.from(JSONObject(cleaned)))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun call(
        apiKey: String,
        model: String,
        userPrompt: String,
        history: List<Pair<String, String>>
    ): Result<String> {
        if (apiKey.isBlank()) {
            return Result.failure(IllegalStateException("Nincs megadva API-kulcs. Nyisd meg a Beállításokat."))
        }

        val contents = JSONArray()
        history.forEach { (role, text) ->
            contents.put(
                JSONObject().apply {
                    put("role", role)
                    put("parts", JSONArray().put(JSONObject().put("text", text)))
                }
            )
        }
        contents.put(
            JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", userPrompt)))
            }
        )

        val body = JSONObject().apply {
            put("contents", contents)
            put(
                "systemInstruction",
                JSONObject().put(
                    "parts",
                    JSONArray().put(JSONObject().put("text", OvenKnowledge.SYSTEM_PROMPT))
                )
            )
            put(
                "generationConfig",
                JSONObject().apply {
                    put("temperature", 0.4)
                    put("responseMimeType", "application/json")
                }
            )
        }

        val url = URL("$BASE/$model:generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 30_000
            readTimeout = 120_000
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("x-goog-api-key", apiKey)
        }

        return try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use(BufferedReader::readText) ?: ""

            if (code !in 200..299) {
                val msg = runCatching {
                    JSONObject(text).optJSONObject("error")?.optString("message")
                }.getOrNull() ?: text.take(300)
                return Result.failure(RuntimeException("Gemini hiba ($code): $msg"))
            }

            val candidates = JSONObject(text).optJSONArray("candidates")
            val parts = candidates?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
            val sb = StringBuilder()
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    sb.append(parts.optJSONObject(i)?.optString("text") ?: "")
                }
            }
            if (sb.isBlank()) {
                Result.failure(RuntimeException("A modell üres választ adott."))
            } else {
                Result.success(sb.toString())
            }
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            conn.disconnect()
        }
    }

    /** Biztonsági háló, ha a modell mégis ```json kerítést tesz a válasz köré. */
    private fun stripFences(s: String): String {
        var t = s.trim()
        if (t.startsWith("```")) {
            t = t.removePrefix("```json").removePrefix("```").trim()
            if (t.endsWith("```")) t = t.removeSuffix("```").trim()
        }
        val first = t.indexOf('{')
        val last = t.lastIndexOf('}')
        return if (first >= 0 && last > first) t.substring(first, last + 1) else t
    }
}
