package hu.kal8989.sutoseged

import org.json.JSONArray
import org.json.JSONObject

data class Phase(
    val nev: String,
    val futesiMod: String,
    val homerseklet: String,
    val idoPerc: Int,
    val szint: String,
    val tartozek: String,
    val teendo: String
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("nev", nev)
        put("futesiMod", futesiMod)
        put("homerseklet", homerseklet)
        put("idoPerc", idoPerc)
        put("szint", szint)
        put("tartozek", tartozek)
        put("teendo", teendo)
    }

    companion object {
        fun from(o: JSONObject) = Phase(
            nev = o.optString("nev"),
            futesiMod = o.optString("futesiMod"),
            homerseklet = o.optString("homerseklet"),
            idoPerc = o.optInt("idoPerc", 0),
            szint = o.optString("szint"),
            tartozek = o.optString("tartozek"),
            teendo = o.optString("teendo")
        )
    }
}

data class Plan(
    val cim: String,
    val osszefoglalo: String,
    val elokeszites: List<String>,
    val fazisok: List<Phase>,
    val maghomerseklet: String,
    val pihentetes: String,
    val magyarazat: String,
    val figyelmeztetes: String
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("cim", cim)
        put("osszefoglalo", osszefoglalo)
        put("elokeszites", JSONArray(elokeszites))
        put("fazisok", JSONArray(fazisok.map { it.toJson() }))
        put("maghomerseklet", maghomerseklet)
        put("pihentetes", pihentetes)
        put("magyarazat", magyarazat)
        put("figyelmeztetes", figyelmeztetes)
    }

    companion object {
        fun from(o: JSONObject): Plan {
            val prep = mutableListOf<String>()
            o.optJSONArray("elokeszites")?.let { arr ->
                for (i in 0 until arr.length()) prep.add(arr.optString(i))
            }
            val phases = mutableListOf<Phase>()
            o.optJSONArray("fazisok")?.let { arr ->
                for (i in 0 until arr.length()) {
                    arr.optJSONObject(i)?.let { phases.add(Phase.from(it)) }
                }
            }
            return Plan(
                cim = o.optString("cim", "Sütési terv"),
                osszefoglalo = o.optString("osszefoglalo"),
                elokeszites = prep,
                fazisok = phases,
                maghomerseklet = o.optString("maghomerseklet"),
                pihentetes = o.optString("pihentetes"),
                magyarazat = o.optString("magyarazat"),
                figyelmeztetes = o.optString("figyelmeztetes")
            )
        }
    }
}

/** Egy mentett terv a hozzá tartozó bemenettel és a saját jegyzeteiddel. */
data class SavedPlan(
    val id: Long,
    val createdAt: Long,
    val inputSummary: String,
    val plan: Plan,
    val notes: List<String>,
    val photoPath: String?
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("createdAt", createdAt)
        put("inputSummary", inputSummary)
        put("plan", plan.toJson())
        put("notes", JSONArray(notes))
        put("photoPath", photoPath ?: "")
    }

    companion object {
        fun from(o: JSONObject): SavedPlan {
            val notes = mutableListOf<String>()
            o.optJSONArray("notes")?.let { arr ->
                for (i in 0 until arr.length()) notes.add(arr.optString(i))
            }
            val photo = o.optString("photoPath", "")
            return SavedPlan(
                id = o.optLong("id", System.currentTimeMillis()),
                createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                inputSummary = o.optString("inputSummary"),
                plan = Plan.from(o.optJSONObject("plan") ?: JSONObject()),
                notes = notes,
                photoPath = photo.ifBlank { null }
            )
        }
    }
}

/** A tervezőlap bemenete. */
data class PlanRequest(
    val etel: String,
    val darabszam: String,
    val osszsulyG: String,
    val vastagsagCm: String,
    val strategia: String,
    val megjegyzes: String
) {
    fun summary(): String {
        val parts = mutableListOf<String>()
        parts.add(etel)
        if (darabszam.isNotBlank()) parts.add("$darabszam db")
        if (osszsulyG.isNotBlank()) parts.add("$osszsulyG g")
        if (vastagsagCm.isNotBlank()) parts.add("$vastagsagCm cm")
        parts.add(strategia)
        return parts.joinToString(" · ")
    }

    fun toUserPrompt(): String = buildString {
        appendLine("Étel / nyersanyag: $etel")
        if (darabszam.isNotBlank()) appendLine("Darabszám: $darabszam")
        if (osszsulyG.isNotBlank()) appendLine("Összsúly: $osszsulyG g")
        if (vastagsagCm.isNotBlank()) appendLine("A legvastagabb rész: $vastagsagCm cm")
        appendLine("Kívánt eredmény / stratégia: $strategia")
        if (megjegyzes.isNotBlank()) appendLine("További megjegyzés: $megjegyzes")
        appendLine()
        appendLine("Készíts ehhez fázistervet a fenti szabályok szerint, JSON-ban.")
    }
}

object Strategies {
    val all = listOf(
        "Gyors – a lényeg, hogy hamar kész legyen",
        "Pecsenye – ropogós kéreg, pirult felület",
        "Lassú sütés – puha, szétomló, kollagén lebontva",
        "Grill – erős felső hő, gyors pirítás",
        "Kímélő párolás – alacsony hő, rozé/szaftos",
        "Air Fry – ropogós, kevés zsírral",
        "Sütemény / tészta"
    )
}

object FoodPresets {
    val all = listOf(
        "Csirke, egész",
        "Csirke, darabolt (comb, felsőcomb)",
        "Csirkemell filé",
        "Csirkeszárny",
        "Kacsacomb",
        "Kacsamell",
        "Pulykamell",
        "Sertéstarja",
        "Sertéskaraj",
        "Sertésszűz",
        "Bőrös sertéssült (lapocka, csülök)",
        "Marhafilé",
        "Marha hátszín",
        "Marha lábszár / párolt sült",
        "Báránycomb",
        "Halfilé – harcsa",
        "Halfilé – lazac",
        "Hal egészben – pisztráng",
        "Halfilé – fehér húsú (tőkehal, süllő)",
        "Zöldség, sült",
        "Burgonya, sült",
        "Sütemény / tészta",
        "Egyéb (írd be)"
    )
}
