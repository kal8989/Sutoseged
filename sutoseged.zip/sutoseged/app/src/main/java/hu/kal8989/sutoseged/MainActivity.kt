package hu.kal8989.sutoseged

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                App()
            }
        }
    }
}

private const val CHANNEL_ID = "sutoseged_timer"

private fun createNotificationChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Sütési fázisok",
            NotificationManager.IMPORTANCE_HIGH
        ).apply { description = "Értesítés a sütési fázis végéről" }
        context.getSystemService(NotificationManager::class.java)
            ?.createNotificationChannel(channel)
    }
}

private fun notifyPhaseDone(context: Context, title: String, text: String) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
        != PackageManager.PERMISSION_GRANTED
    ) return

    val n = NotificationCompat.Builder(context, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_popup_reminder)
        .setContentTitle(title)
        .setContentText(text)
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setAutoCancel(true)
        .build()

    runCatching {
        context.getSystemService(NotificationManager::class.java)
            ?.notify(System.currentTimeMillis().toInt(), n)
    }
}

// ---------------------------------------------------------------- App

@Composable
fun App() {
    val context = LocalContext.current
    val store = remember { Store(context) }
    var tab by remember { mutableIntStateOf(0) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    label = { Text("Tervező") },
                    icon = { Text("🔥", fontSize = 18.sp) }
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    label = { Text("Mentett") },
                    icon = { Text("📒", fontSize = 18.sp) }
                )
                NavigationBarItem(
                    selected = tab == 2,
                    onClick = { tab = 2 },
                    label = { Text("Beállítás") },
                    icon = { Text("⚙️", fontSize = 18.sp) }
                )
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (tab) {
                0 -> PlannerScreen(store)
                1 -> SavedScreen(store)
                else -> SettingsScreen(store)
            }
        }
    }
}

// ---------------------------------------------------------------- Tervező

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlannerScreen(store: Store) {
    val scope = rememberCoroutineScope()

    var foodPreset by remember { mutableStateOf(FoodPresets.all.first()) }
    var foodCustom by remember { mutableStateOf("") }
    var darab by remember { mutableStateOf("") }
    var suly by remember { mutableStateOf("") }
    var vastagsag by remember { mutableStateOf("") }
    var strategia by remember { mutableStateOf(Strategies.all[1]) }
    var megjegyzes by remember { mutableStateOf("") }

    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var plan by remember { mutableStateOf<Plan?>(null) }
    var savedNote by remember { mutableStateOf<String?>(null) }

    var foodMenu by remember { mutableStateOf(false) }
    var stratMenu by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Sütési terv", fontWeight = FontWeight.Bold, fontSize = 22.sp)

        ExposedDropdownMenuBox(
            expanded = foodMenu,
            onExpandedChange = { foodMenu = !foodMenu }
        ) {
            OutlinedTextField(
                value = foodPreset,
                onValueChange = {},
                readOnly = true,
                label = { Text("Nyersanyag") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = foodMenu) },
                modifier = Modifier
                    .menuAnchor()
                    .fillMaxWidth()
            )
            ExposedDropdownMenu(expanded = foodMenu, onDismissRequest = { foodMenu = false }) {
                FoodPresets.all.forEach { item ->
                    DropdownMenuItem(
                        text = { Text(item) },
                        onClick = { foodPreset = item; foodMenu = false }
                    )
                }
            }
        }

        if (foodPreset.startsWith("Egyéb")) {
            OutlinedTextField(
                value = foodCustom,
                onValueChange = { foodCustom = it },
                label = { Text("Mi az?") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = darab,
                onValueChange = { darab = it.filter { c -> c.isDigit() } },
                label = { Text("Darab") },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                    keyboardType = KeyboardType.Number
                ),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = suly,
                onValueChange = { suly = it.filter { c -> c.isDigit() } },
                label = { Text("Összsúly (g)") },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                    keyboardType = KeyboardType.Number
                ),
                modifier = Modifier.weight(1.3f)
            )
        }

        OutlinedTextField(
            value = vastagsag,
            onValueChange = { vastagsag = it.filter { c -> c.isDigit() || c == '.' || c == ',' } },
            label = { Text("Legvastagabb rész (cm) – nem kötelező") },
            modifier = Modifier.fillMaxWidth()
        )

        ExposedDropdownMenuBox(
            expanded = stratMenu,
            onExpandedChange = { stratMenu = !stratMenu }
        ) {
            OutlinedTextField(
                value = strategia,
                onValueChange = {},
                readOnly = true,
                label = { Text("Mit szeretnél?") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = stratMenu) },
                modifier = Modifier
                    .menuAnchor()
                    .fillMaxWidth()
            )
            ExposedDropdownMenu(expanded = stratMenu, onDismissRequest = { stratMenu = false }) {
                Strategies.all.forEach { item ->
                    DropdownMenuItem(
                        text = { Text(item) },
                        onClick = { strategia = item; stratMenu = false }
                    )
                }
            }
        }

        OutlinedTextField(
            value = megjegyzes,
            onValueChange = { megjegyzes = it },
            label = { Text("Megjegyzés (pác, köret, korábbi tapasztalat…)") },
            minLines = 2,
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                error = null
                savedNote = null
                val etel = if (foodPreset.startsWith("Egyéb")) foodCustom else foodPreset
                if (etel.isBlank()) {
                    error = "Add meg, mit sütsz."
                    return@Button
                }
                val req = PlanRequest(etel, darab, suly, vastagsag, strategia, megjegyzes)
                loading = true
                scope.launch {
                    val result = Gemini.plan(store.apiKey, store.model, req.toUserPrompt())
                    loading = false
                    result.fold(
                        onSuccess = { plan = it },
                        onFailure = { error = it.message ?: "Ismeretlen hiba" }
                    )
                }
            },
            enabled = !loading,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (loading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.onPrimary
                )
                Spacer(Modifier.width(10.dp))
                Text("Tervezés…")
            } else {
                Text("Terv készítése")
            }
        }

        error?.let {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer
                )
            ) {
                Text(it, Modifier.padding(12.dp))
            }
        }

        plan?.let { p ->
            HorizontalDivider()
            PlanView(p)
            savedNote?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
            OutlinedButton(
                onClick = {
                    val etel = if (foodPreset.startsWith("Egyéb")) foodCustom else foodPreset
                    val req = PlanRequest(etel, darab, suly, vastagsag, strategia, megjegyzes)
                    store.addPlan(req.summary(), p)
                    savedNote = "Mentve a Mentett fülre."
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Terv mentése") }
        }

        Spacer(Modifier.height(24.dp))
    }
}

// ---------------------------------------------------------------- Terv megjelenítése

@Composable
fun PlanView(plan: Plan) {
    var showWhy by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(plan.cim, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        if (plan.osszefoglalo.isNotBlank()) {
            Text(plan.osszefoglalo, fontSize = 14.sp)
        }

        if (plan.figyelmeztetes.isNotBlank()) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.tertiaryContainer
                )
            ) {
                Text("⚠️ ${plan.figyelmeztetes}", Modifier.padding(12.dp), fontSize = 14.sp)
            }
        }

        if (plan.elokeszites.isNotEmpty()) {
            Text("Előkészítés", fontWeight = FontWeight.SemiBold)
            plan.elokeszites.forEach { Text("• $it", fontSize = 14.sp) }
        }

        Text("Fázisok", fontWeight = FontWeight.SemiBold)
        plan.fazisok.forEachIndexed { i, ph -> PhaseCard(i + 1, ph) }

        if (plan.maghomerseklet.isNotBlank()) {
            Card {
                Column(Modifier.padding(12.dp)) {
                    Text("Maghőmérséklet", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text(plan.maghomerseklet, fontSize = 14.sp)
                }
            }
        }

        if (plan.pihentetes.isNotBlank()) {
            Text("Pihentetés: ${plan.pihentetes}", fontSize = 14.sp)
        }

        if (plan.magyarazat.isNotBlank()) {
            TextButton(onClick = { showWhy = !showWhy }) {
                Text(if (showWhy) "Magyarázat elrejtése" else "Miért így? – magyarázat")
            }
            if (showWhy) {
                Card {
                    Text(plan.magyarazat, Modifier.padding(12.dp), fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
fun PhaseCard(index: Int, phase: Phase) {
    val context = LocalContext.current
    var remaining by remember { mutableIntStateOf(phase.idoPerc * 60) }
    var running by remember { mutableStateOf(false) }

    LaunchedEffect(running) {
        while (running && remaining > 0) {
            delay(1000)
            remaining--
        }
        if (running && remaining <= 0) {
            running = false
            notifyPhaseDone(
                context,
                "Fázis kész: ${phase.nev}",
                "${phase.futesiMod} · ${phase.homerseklet}"
            )
        }
    }

    Card(shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("$index. ${phase.nev}", fontWeight = FontWeight.Bold)
            Text("${phase.futesiMod} · ${phase.homerseklet}", fontSize = 14.sp)
            Text(
                "Szint: ${phase.szint}   ·   ${phase.tartozek}",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (phase.teendo.isNotBlank()) {
                Text(phase.teendo, fontSize = 13.sp)
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(top = 4.dp)
            ) {
                Text(
                    formatTime(remaining),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                if (phase.idoPerc > 0) {
                    Button(onClick = { running = !running }) {
                        Text(if (running) "Állj" else "Indít")
                    }
                    OutlinedButton(onClick = {
                        running = false
                        remaining = phase.idoPerc * 60
                    }) { Text("Nulláz") }
                }
            }
        }
    }
}

private fun formatTime(seconds: Int): String {
    val s = seconds.coerceAtLeast(0)
    return String.format(Locale.getDefault(), "%02d:%02d", s / 60, s % 60)
}

// ---------------------------------------------------------------- Mentett tervek

@Composable
fun SavedScreen(store: Store) {
    val context = LocalContext.current
    var plans by remember { mutableStateOf(store.loadPlans()) }
    var open by remember { mutableStateOf<SavedPlan?>(null) }

    val fmt = remember { SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.getDefault()) }

    val current = open
    if (current != null) {
        var noteText by remember(current.id) { mutableStateOf("") }
        var pendingPhoto by remember(current.id) { mutableStateOf<File?>(null) }
        var item by remember(current.id) { mutableStateOf(current) }

        val cameraLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.TakePicture()
        ) { ok ->
            if (ok) {
                pendingPhoto?.let { f ->
                    item = item.copy(photoPath = f.absolutePath)
                    store.updatePlan(item)
                    plans = store.loadPlans()
                }
            }
        }

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            TextButton(onClick = { open = null }) { Text("‹ Vissza a listához") }
            Text(
                item.inputSummary,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            PlanView(item.plan)

            item.photoPath?.let { path ->
                val bmp = remember(path) { BitmapFactory.decodeFile(path) }
                bmp?.let {
                    Image(
                        bitmap = it.asImageBitmap(),
                        contentDescription = "A kész étel",
                        contentScale = ContentScale.FillWidth,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 260.dp)
                    )
                }
            }

            OutlinedButton(
                onClick = {
                    val f = store.newPhotoFile()
                    pendingPhoto = f
                    val uri: Uri = FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        f
                    )
                    cameraLauncher.launch(uri)
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (item.photoPath == null) "Fénykép a kész ételről" else "Új fénykép") }

            HorizontalDivider()
            Text("Jegyzetek", fontWeight = FontWeight.SemiBold)
            if (item.notes.isEmpty()) {
                Text(
                    "Még nincs jegyzet. Írd ide, ha máskor másképp csinálnád.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            item.notes.forEach { Text("• $it", fontSize = 14.sp) }

            OutlinedTextField(
                value = noteText,
                onValueChange = { noteText = it },
                label = { Text("Új jegyzet") },
                minLines = 2,
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    if (noteText.isNotBlank()) {
                        item = item.copy(notes = item.notes + noteText.trim())
                        store.updatePlan(item)
                        plans = store.loadPlans()
                        noteText = ""
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Jegyzet hozzáadása") }

            OutlinedButton(
                onClick = {
                    store.deletePlan(item.id)
                    plans = store.loadPlans()
                    open = null
                },
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = MaterialTheme.colorScheme.error
                ),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Terv törlése") }

            Spacer(Modifier.height(24.dp))
        }
        return
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Mentett tervek", fontWeight = FontWeight.Bold, fontSize = 22.sp)
        if (plans.isEmpty()) {
            Text(
                "Még nincs mentett terved.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 24.dp),
                textAlign = TextAlign.Center
            )
        }
        plans.forEach { sp ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { open = sp }
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text(sp.plan.cim, fontWeight = FontWeight.SemiBold)
                    Text(
                        sp.inputSummary,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        fmt.format(Date(sp.createdAt)) +
                            if (sp.notes.isNotEmpty()) "  ·  ${sp.notes.size} jegyzet" else "",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

// ---------------------------------------------------------------- Beállítások

@Composable
fun SettingsScreen(store: Store) {
    var key by remember { mutableStateOf(store.apiKey) }
    var model by remember { mutableStateOf(store.model) }
    var saved by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Beállítások", fontWeight = FontWeight.Bold, fontSize = 22.sp)

        OutlinedTextField(
            value = key,
            onValueChange = { key = it; saved = false },
            label = { Text("Gemini API-kulcs") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = model,
            onValueChange = { model = it; saved = false },
            label = { Text("Modell neve") },
            modifier = Modifier.fillMaxWidth()
        )

        Text(
            "Ismert modellek: " + Store.KNOWN_MODELS.joinToString(", "),
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Store.KNOWN_MODELS.forEach { m ->
                AssistChip(onClick = { model = m; saved = false }, label = { Text(m.removePrefix("gemini-")) })
            }
        }

        Button(
            onClick = {
                store.apiKey = key.trim()
                store.model = model.trim().ifBlank { Store.DEFAULT_MODEL }
                saved = true
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Mentés") }

        if (saved) Text("Elmentve.", color = MaterialTheme.colorScheme.primary)

        HorizontalDivider()
        Text(
            "A kulcs csak ezen a telefonon tárolódik. A sütő adatai (fűtési módok, " +
                "gyári beállítási táblázat) az appba vannak építve, azokat nem kell megadni.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(24.dp))
    }
}
